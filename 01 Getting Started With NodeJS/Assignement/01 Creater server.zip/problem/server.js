const server= require('./index');
const port = 8080;

server.listen(port,()=>{
    console.log(`Configure the server to listen on port ${port}`)
})

